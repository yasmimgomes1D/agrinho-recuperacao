let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["👩🏼‍🦰", "🐩", "👩🏽‍🌾", "🐄"];
let teclas = ["a", "s", "d", "f"];
let quantidade = jogador.length;

let vencedor = null;
let jogoAtivo = false;
let tempoContagem = 0;

// Configuração inicial
function setup() {
  createCanvas(400, 400);
  textAlign(CENTER, CENTER);
  iniciarContagemRegressiva();
}

function draw() {
  background("#795548");

  if (!jogoAtivo && vencedor === null) {
    atualizarContagemRegressiva();
    exibirInstrucoes(); // ⬅️ AQUI mostramos as instruções
    return;
  }

  desenharCenario();
  atualizarJogo();
  exibirResultadoSeHouver();
}

// -------------------------- Funções principais --------------------------

function desenharCenario() {
  desenharLinhaDeChegada();
  desenharJogadores();
}

function atualizarJogo() {
  verificarVencedor();
}

function exibirResultadoSeHouver() {
  if (vencedor !== null) {
    exibirMensagemDeVencedor();
  }
}

// -------------------------- Funções auxiliares --------------------------

function desenharJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xJogador[i], yJogador[i]);
  }
}

function desenharLinhaDeChegada() {
  fill("#000000");
  rect(350, 0, 10, 400);
  fill("#FFFFFF");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificarVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350 && vencedor === null) {
      vencedor = i;
      jogoAtivo = false;
    }
  }
}

function exibirMensagemDeVencedor() {
  fill(255);
  textSize(28);
  text(jogador[vencedor] + " venceu!", width / 2, height / 2 - 20);
  textSize(16);
  text("Clique para reiniciar", width / 2, height / 2 + 20);
}

function iniciarContagemRegressiva() {
  tempoContagem = millis();
}

function atualizarContagemRegressiva() {
  let tempoPassado = millis() - tempoContagem;
  let segundos = 10 - floor(tempoPassado / 1000);

  if (segundos <= 0) {
    jogoAtivo = true;
    return;
  }

  fill(255);
  textSize(48);
  text(segundos, width / 2, height / 2);
}

function exibirInstrucoes() {
  fill(255);
  textSize(16);
  text("👩🏼‍🦰 tecla A", width / 2, height / 2 + 60);
  text("🐩 tecla S", width / 2, height / 2 + 80);
  text("👩🏽‍🌾 tecla D", width / 2, height / 2 + 100);
  text("🐄 tecla F", width / 2, height / 2 + 120);
  text("O primeiro a alcançar a linha preta vence!", width / 2, height / 2 + 150);
}

function reiniciarJogo() {
  for (let i = 0; i < quantidade; i++) {
    xJogador[i] = 0;
  }
  vencedor = null;
  jogoAtivo = false;
  iniciarContagemRegressiva();
}

// -------------------------- Eventos --------------------------

function keyReleased() {
  if (!jogoAtivo) return;

  for (let i = 0; i < quantidade; i++) {
    if (key.toLowerCase() === teclas[i]) {
      xJogador[i] += random(10, 15); // velocidade ajustada
    }
  }
}

function mousePressed() {
  if (vencedor !== null) {
    reiniciarJogo();
  }
}